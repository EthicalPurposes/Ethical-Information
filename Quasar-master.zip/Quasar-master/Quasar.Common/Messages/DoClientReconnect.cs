﻿using ProtoBuf;

namespace Quasar.Common.Messages
{
    [ProtoContract]
    public class DoClientReconnect : IMessage
    {
    }
}
