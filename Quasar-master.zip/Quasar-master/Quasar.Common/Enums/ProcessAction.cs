﻿namespace Quasar.Common.Enums
{
    public enum ProcessAction
    {
        Start,
        End
    }
}
